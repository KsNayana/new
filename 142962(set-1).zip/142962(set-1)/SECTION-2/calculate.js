function calculateCharges()
{
var cno=frm.consumerno.value;
var cname=frm.consumername.value;
var mail=frm.consumeremail.value;
var unitsConsumed=frm.noOfUnits.value;
var totalCharge;
if(unitsConsumed>=0 && unitsConsumed<=100) {
	totalCharge=Math.round(2.80*unitsConsumed); }
else if(unitsConsumed>=101 && unitsConsumed<=200) {
	totalCharge=Math.round(3.90*unitsConsumed); }
else if(unitsConsumed>200) {
	totalCharge=Math.round(4.50*unitsConsumed); }
	displayDetails(totalCharge);
}
function displayDetails(totalCharge){
var cno=frm.consumerno.value;
var cname=frm.consumername.value;
var mail=frm.consumeremail.value;
var unitsConsumed=frm.noOfUnits.value;
	var win = window.open('','','width=500,height=300,left=150');
	win.alert("Consumer No: "+cno);
	win.alert("Consumer Name: "+cname);
	win.alert("Email Address: "+mail);
	win.alert("Number of Units: "+unitsConsumed);
	win.alert("Total Electricity Charges:  "+totalCharge);
	win.close();
}