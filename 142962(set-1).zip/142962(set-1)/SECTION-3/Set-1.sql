Drop table Faculty cascade constraints;
Drop Table Course cascade constraints;

CREATE TABLE Faculty(facultyId  NUMBER PRIMARY KEY, Faculty_Name VARCHAR2(20),LOT VARCHAR2(10));

CREATE TABLE Course(courseId Number primary KEY,Course_name varchar2(20),
Location varchar2(15),LabNo varchar2(10),facultyId references Faculty(facultyId) ,startDate Date,
endDate Date );


insert into Faculty values (101,'Veena', 'JEE');
insert into Faculty values (102,'Mahima', 'JEE');
insert into Faculty values (103,'Vaishali', 'JEE');
insert into Faculty values (104,'Shital', 'DotNet');
insert into Faculty values (105,'Rahul', 'DotNet');
insert into Faculty values (106,'Karthik', 'MainFrame');
insert into Faculty values (107,'Rohini', 'JEE');
insert into Faculty values (108,'Reshma', 'DotNet');


insert into Course values (1,'Servlet','Pune','F101',101,'12-Apr-2016','14-Apr-2016');
insert into Course values (2,'JSP 2.2','Pune','F102',103,'5-Oct-2016','8-Oct-2016');
insert into Course values (3,'Windows Programming','Mumbai','G103',103,'2-May-2016','8-May-2016');
insert into Course values (4,'OOP and UML','Mumbai','G101',104,'3-Jan-2016','4-Jan-2016');
insert into Course values (5,'HTML 5','Bangalore','G101',104,'9-Nov-2016','12-Nov-2016');
insert into Course values (6,'Windows Presentation','Bangalore','G101',104,'16-July-2016','22-July-2016');
COMMIT;

