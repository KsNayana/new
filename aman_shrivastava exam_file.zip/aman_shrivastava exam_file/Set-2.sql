Drop table Customer cascade constraints;
Drop table Orders cascade constraints;

CREATE TABLE Customer(CustId NUMBER PRIMARY KEY, Name VARCHAR2(20),  MobileNo NUMBER(11), Email VARCHAR2(30));


INSERT INTO customer VALUES(1001,'Priya',9982212345,'priya@gmail.com ');
INSERT INTO customer VALUES(1002,'Anu',9982254321,'anu@gmail.com');
INSERT INTO customer VALUES(1003,'Arun',9982287335,'arun@yahoo.com');
INSERT INTO customer VALUES(1004,'Shyam',9999912345,'shyam@rediff.com');
INSERT INTO customer VALUES(1005,'Priyank',9982233123,'priyank@capgemisni.com');


CREATE TABLE Orders(OrderId VARCHAR2(10) PRIMARY KEY, pname VARCHAR2(30), Qty NUMBER(4), Price NUMBER(6,2), CustId NUMBER references Customer(CustID));

insert into Orders values('OR001','Laptop',4,3000,1001);
insert into Orders values('OR002','Mobile',1,4000,1001);
insert into Orders values('OR003','Cosmetics',2,8000,1001);
insert into Orders values('OR004','Cosmetics',2,2000,1003);
insert into Orders values('OR005','Mobile',4,6000,1003);
insert into Orders values('OR006','USB Cable',2,600,1002);
insert into Orders values('OR007','USB Cable',4,600,1003);
COMMIT;


