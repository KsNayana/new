
function validate() {
	
	var totalPrice= classPrice();
	var enter_tax= entertain_tax(totalPrice);
	var payable_amount= totalPrice + enter_tax;
	generate_details(payable_amount);
	}
	
	
	
	function classPrice(){
	var movieClass = frm.cls.value;
	if(movieClass=='cls1')
	{
	var price=300;
	var total_Price=price*tickets;
	return total_Price;
	}
	else if(movieClass=='cls2')
	{
	var price=250;
	var total_Price=price*tickets;
	return total_Price;
	}
	}
	
    function entertain_tax(totalPrice)
	{
	var ent_tax= 0.12*totalPrice;
	return ent_tax;
	}
	
	function generate_details(payable_amount)
	{
	
	
	var newWindow = window.open('','','width=300,height=200,left=150');
	// populating ticket details along with ticketId in new window.
	newWindow.document.write("Customer Name::" + frm.uname.value + "<br>");
	newWindow.document.write("Mobile Number::" + frm.num1.value + "<br>");
	newWindow.document.write("No of Tickets::" + frm.num.value + "<br>");
	newWindow.document.write("Payable Amount::" + payable_amount + "<br>");
	
}
	