public abstract class Shape 
{
	public Shape ()
	{}
	public void drawShape()
	{
		System.out.println(""+"shape is drwan with RED");
		
	}
	public abstract double calcArea();
	public abstract double calcPerimeter();
	
}


