
public class TestDrawingApp 
{

	public static void main(String[] args)
	{
		Shape shape1=new Circle(5);
		Shape shape2=new Circle(5);
		Shape shape3=new Sphere(5);
		
		System.out.println("Area:" +shape1.calcArea());
		System.out.println("Perimeter:" +shape1.calcPerimeter());
		System.out.println("Area:" +shape2.calcArea());
		System.out.println("Perimeter:" +shape2.calcPerimeter());

	}

}
