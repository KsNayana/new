
public class TestPersonDemo {

	public static void main(String[] args)
	{
		Person p1=new Person ("Vaishali S","CBH78GP",10);
		Person p2=new Person ("Vishal S","CBH78GPg",15);
		Person p3=new Person ("Vaishali S","CBH78GP",10);
		System.out.println(p1);
		System.out.println(p2.toString());
	
	if (p1.equals(p3))
	{
		System.out.println("SAme");
	}
	else
		System.out.println("Not SAme");

	Integer i1=new Integer(10);
	Integer i2=new Integer(20);
	Integer i3=new Integer(30);
	System.out.println("i1="+i1);
	System.out.println("i2="+i2);
	System.out.println("i3="+i3);
	
	if(i1.equals(i2))
	{
		System.out.println("SAme");
	}
	else
		System.out.println("Not SAme");
	
	System.out.println("HashCode of P1 "+p1.hashCode());
	System.out.println("HashCode of P2 "+p2.hashCode());
	System.out.println("HashCode of P3 "+p3.hashCode());
	
	System.out.println("HashCode of i1 "+i1.hashCode());
	System.out.println("HashCode of i2 "+i2.hashCode());
	System.out.println("HashCode of i3 "+i3.hashCode());
}
}
