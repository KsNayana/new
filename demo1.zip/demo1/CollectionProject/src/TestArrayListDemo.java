import java.util.*;


public class TestArrayListDemo
{

	public static void main(String[] args)
	{
		ArrayList<Integer> intList = new ArrayList<Integer>();
		
		Integer i1 = new Integer(10);
		Integer i2 = new Integer(5);
		Integer i3 = new Integer(12);
		Integer i4 = new Integer(13);
		Integer i5 = new Integer(14);
		
		intList.add(i1);
		intList.add(i2);
		intList.add(i3);
		intList.add(i4);
		intList.add(i5);
		
			System.out.println("*******Without Iterator*******");
			System.out.println(intList);
			System.out.println("******With Iterator************");
			Iterator<Integer> it =intList.iterator();
			while(it.hasNext())
			{
				Integer tempEntry=it.next();
				System.out.println(" : " +tempEntry);
			}
		
		}
			

		

	}


