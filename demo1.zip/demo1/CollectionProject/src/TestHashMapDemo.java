import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;



public class TestHashMapDemo 
{

	public static void main(String[] args)
	{
		HashMap<Long,String>mobileDirectory=new HashMap<Long,String>();
		
		mobileDirectory.put(888882389238L,"VaishaliS");
		mobileDirectory.put(19582389238L,"Nayanas");
		mobileDirectory.put(85582389238L,"Nayanakattas");
		mobileDirectory.put(5465845489238L,"Krishh");
		mobileDirectory.put(777782389238L,"ram");
		
		Set<Entry<Long,String>> setIt=mobileDirectory.entrySet();
		
		Iterator<Entry<Long,String>>mobIt=setIt.iterator();
		while(mobIt.hasNext())
		{
			Entry<Long,String> dirEntry=mobIt.next();
			System.out.println("Mobile:" +dirEntry.getKey()+ "  Name: "+dirEntry.getValue());
		}


	}

}
