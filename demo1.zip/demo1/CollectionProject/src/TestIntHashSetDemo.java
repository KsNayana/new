import java.util.HashSet;
public class TestIntHashSetDemo {

	public static void main(String[] args) {
		

	
		HashSet<Integer> intSet= new HashSet<Integer>();

		Integer i1 = new Integer(10);
		Integer i2 = new Integer(5);
		Integer i3 = new Integer(12);
		Integer i4 = new Integer(14);
		Integer i5 = new Integer(14);

		 intSet.add(i1);
		 intSet.add(i2);
		 intSet.add(i3);
		 intSet.add(i4);
		 intSet.add(i5);

			System.out.println("*******Without Iterator*******");
			System.out.println(intSet);
		}

	}


