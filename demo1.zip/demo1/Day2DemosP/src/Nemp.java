import java.util.Scanner;




public class Nemp {

	public static void main(String[] args) {
		
			Scanner sc =new Scanner(System.in);
			System.out.println("Enter the number of employee:");
			int count =sc.nextInt();
			Employee allemployees[] = new Employee[count];
			Date empDOJ;
			int empId =0;
			String empNames="Unknown";
			float empSal=0.0F;
			int day=0;
			int mon=0;
			int year=0;
			
			for (int i=0;i<allemployees.length;i++)
			{
	            System.out.println("Enter Name of person:");
				
				 empNames=sc.next();
				
				System.out.println("Enter Id:");
				 empId= sc.nextInt();
				
				System.out.println("Enter salary:");
				 empSal= sc.nextFloat();
				 
				 System.out.println("Enter day:");
				 day= sc.nextInt();
				
				System.out.println("Enter Month:");
				 mon= sc.nextInt();
				
				System.out.println("Enter Year:");
				 year= sc.nextInt();
				
				 empDOJ=new Date(day,mon,year);
				 allemployees[i] =new Employee(empId,empNames,empSal,empDOJ);
			
				}
			for (int j=0; j<allemployees.length;j++)
			{
				System.out.println("Details of person:" +allemployees[j].dispEmpInfo());
			}

}
}
