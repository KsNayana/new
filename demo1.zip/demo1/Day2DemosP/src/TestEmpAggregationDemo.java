
public class TestEmpAggregationDemo {

	public static void main(String[] args) 
	{
		
		Date vaiDOJ = new Date(01,04,2015);
		Date nayDOJ = new Date(12,12,2018);
		
		Employee vaishali=new Employee(112081,"vaishali",1000.0F,vaiDOJ);
		Employee nayana=new Employee(112082,"nayana",1005.0F,nayDOJ);
		
		System.out.println(vaishali.dispEmpInfo());
		System.out.println(nayana.dispEmpInfo());
	}

}
