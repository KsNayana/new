import java.util.Scanner;


public class TestABankAppDemo {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		
		int currentBalance =60000;
		
		System.out.println("Enter the withdrawal Amount" );
		int withDrawAmt =sc.nextInt();
		if(withDrawAmt<currentBalance)
		{
			System.out.println("OK U have sufficient balance to withdraw" );
		}
		else
		{
			try 
			{
				throw new LowBalanceException
				("please check the balance");
			} 
			catch (LowBalanceException e) 
			{
				System.out.println("Insufficient Balance");
				e.printStackTrace();
			}
		}
	}

}
