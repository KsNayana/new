import java.io.IOException;

public class ThrowsDemo 
{
	public void method1()throws IOException
	{
		System.out.println("inside mathod 1");

		method2();
	}
	public void method2()
	{
		System.out.println("inside mathod 2");
		
		throw new ArrayIndexOutOFBoundsException();
		
	}
}
