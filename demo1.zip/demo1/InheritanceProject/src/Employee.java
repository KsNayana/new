
public class Employee
{
	private int empId;
	private String empName;
	private float empSal;
	public Employee(){};
	public Employee(int empId,String empName, float empSal)
	{
		this.empId=empId;
		this.empName=empName;
		this.empSal=empSal;
	}
	
	public String dispEmpInfo() {
		return "empId=" + empId + ", empName=" + empName
				+ ", emp Basic Sal=" + empSal ;
	}
	public float calcEmpBasicSal()
	{
		return empSal;
	}
	public float calcEmpAnnualSal()
	{
		return calcEmpBasicSal()*12;
	}
	
	
}
