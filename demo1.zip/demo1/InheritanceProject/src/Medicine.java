public class Medicine {

    private String expiryDate;
    private int price;
    private String medName;
    private String companyName;
    
    public Medicine() {
        
    }
    
    public Medicine( String medName,String expiryDate, int price,
            String companyName) {
        super();
        this.medName = medName;
        this.expiryDate = expiryDate;
        this.price = price;
       
        this.companyName = companyName;
    }



    public String dispInfo()
    {
        return "\nMedicine Name: "+ medName +
        "\nCompany Name: "+ companyName+
        "\nMedicine expiry date: "+ expiryDate+
        "\nMedicine price: "+ price;
    }
    
}