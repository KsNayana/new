

    public class Ointment extends Medicine{

        public Ointment() {
            super();
        }

        public Ointment( String medName,String expiryDate, int price,
                String companyName) {
            super(medName,expiryDate, price,  companyName);
            
        }
        
        public String dispInfo(){
            return super.dispInfo()+  "\nOnly for external use!";
                   
        }
    }

