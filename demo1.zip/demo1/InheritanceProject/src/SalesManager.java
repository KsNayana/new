
public class SalesManager extends WageEmp 
{
	private int sales;
	private int comm;
	
	public SalesManager()
	{
		super();
		
	}
	public SalesManager(int empId,String empName, float empSal, int noOfHrs,int ratePerHrs,int sales,int comm)
	{
		super( empId, empName,  empSal,  noOfHrs,ratePerHrs);
		this.sales=sales;
		this.comm=comm;
	
	}
	public float calcEmpBasicSal()
	{
		return super.calcEmpBasicSal()+(sales*comm);
	}
	public float calcEmpAnnualSal()
	{
		return calcEmpBasicSal()*12;
	}
}
