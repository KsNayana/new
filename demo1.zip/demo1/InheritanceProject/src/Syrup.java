
public class Syrup extends Medicine{

    public Syrup() {
        super();
        
    }

    public Syrup(String medName,String expiryDate, int price, 
            String companyName) {
        super( medName,expiryDate, price, companyName);
        
    }
    
    public String dispInfo(){
        return super.dispInfo()+
                "\nShake well before use!";
    }
    

}