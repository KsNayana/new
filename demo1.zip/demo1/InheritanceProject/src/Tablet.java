
public class Tablet extends Medicine{

    public Tablet() {
        super();
    }

    public Tablet(String medName,String expiryDate, int price, 
            String companyName) {
        super( medName,expiryDate, price, companyName);
        
    }

    public String dispInfo(){
        return super.dispInfo()+
                "\nStore in cool and dry place!";
    }
}
