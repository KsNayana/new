import java.util.Scanner;
public class TestInheritanceDemo2 {

	public static void main(String[] args)
	{
	
		
		Scanner sc = new Scanner(System.in);
		System.out.println("How Many Employee?");
		int empCount=sc.nextInt();
		
	    Employee empArr[] = new Employee[empCount];
	
	    int eId=0;
	    String eName=null;
	    float eSal =0.0F;
	    int noOfHrs, ratePerHr,Sale;
		
		for(int i =0;i<empCount;i++)
		{
			
		
		System.out.println("Enter empId");
		eId = sc.nextInt();
		
		System.out.println("Enter empName");
		eName = sc.next();
		
		System.out.println("Enter salary");
		eSal = sc.nextFloat();
		
		System.out.println("What type of Employee you want?" +"1:Permanent Employee \n"
				+ "2: waged employee"+"3:SAlesManager");
		
		int choice=sc.nextInt();
		
		switch (choice)
		{
			case 1:
				empArr[i] = new Employee(eId,eName,eSal);
				break;
				
			case 2:
			
				System.out.println("Enter No of Hours U worked");
				noOfHrs=sc.nextInt();
				System.out.println("Enter rate per Hour");
				ratePerHr=sc.nextInt();
				empArr[i]=new WageEmp(eId,eName,eSal,noOfHrs,ratePerHr);
				break;
				
			default:
				
				System.out.println("Enter No of Hours U worked");
				noOfHrs=sc.nextInt();
				System.out.println("Enter rate per Hour");
				ratePerHr=sc.nextInt();
				System.out.println("Enter Sales U have done");
				int sales=sc.nextInt();
				System.out.println("Enter commision");
				int comm=sc.nextInt();
				empArr[i]=new SalesManager(eId,eName,eSal,noOfHrs,ratePerHr,sales,comm);
					
		}
		
	}
		System.out.println("*************************************");
		
			for(int j=0;j<empArr.length;j++)
			{
				if( empArr[j] instanceof SalesManager)
				{
					System.out.println("Sales Manager: "+empArr[j].dispEmpInfo()+"monthly Basic"
							+ empArr[j].calcEmpBasicSal()+ "Annual sal: "+empArr[j].calcEmpAnnualSal());
				}
				else if( empArr[j] instanceof WageEmp)
				{
					System.out.println("Wage Emp: "+empArr[j].dispEmpInfo()+"monthly Basic"
							+ empArr[j].calcEmpBasicSal()+ "Annual sal: "+empArr[j].calcEmpAnnualSal());
				}
				else
				{
					System.out.println("Employee: "+empArr[j].dispEmpInfo()+"monthly Basic"
							+ empArr[j].calcEmpBasicSal()+ "Annual sal: "+empArr[j].calcEmpAnnualSal());
				}
			}
		
}
}
