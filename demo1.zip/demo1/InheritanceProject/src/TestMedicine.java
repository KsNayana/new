

import java.util.Scanner;
public class TestMedicine {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the no of medicine");
        int medCount = sc.nextInt();
        String medName,medCompany,medDate;
        int medPrice;
        
        Medicine med[] = new Medicine[medCount];

        for (int index = 0; index < medCount; index++)
        {
            System.out.println("\nEnter Medicine Name: ");
            medName = sc.next();
            System.out.println("Enter Company Name: ");
            medCompany = sc.next();
            System.out.println("Enter Medicine Expiry Date: ");
            medDate = sc.next();
            System.out.println("Enter Medicine  Price: ");
            medPrice = sc.nextInt();
            
            System.out.println("\nWhat type of Medicine u want?"+
            "\n1:Tablet\t2:Ointment\t3:Syrup");
            System.out.println("\nEnter choice!");
            int choice = sc.nextInt();
            
            switch(choice)
            {
            case 1: 
                    med[index] = new Tablet(medName,medDate,medPrice,medCompany);
                    break;
                    
            case 2:
                    med[index] = new Ointment(medName,medDate,medPrice,medCompany);
                    break;
                    
            default:
                    
                    med[index] = new Syrup(medName,medDate,medPrice,medCompany);
                
            }   
        }
        
        for(int index=0; index<medCount; index++)
        {
            if(med[index] instanceof Syrup) 
            {
            System.out.println("\nSyrup Info: " +med[index].dispInfo());
            }
            else if(med[index] instanceof Ointment)
            {
            System.out.println("\nOintment Info: " +med[index].dispInfo());
            }
            else    
            {
            System.out.println("\nTablet Info: " +med[index].dispInfo());
            }
        }
    }

}
