
public class TestStaticempDemo
{
	static
	{
		System.out.println("staticDemo");
		
	}

	public static void main(String[] args) 
	{
		Emp e1= new Emp(111,"nayana",1000.0F);
		Emp e2= new Emp(112,"navya",1001.0F);
		
		Emp e3= new Emp(113,"namratha",1002.0F);
		System.out.println(e1.dispEmpInfo());
		System.out.println(e2.dispEmpInfo());
		System.out.println(e3.dispEmpInfo());
		Emp.getCount();
		show();

	}
	
	private   static void show()
	{
		System.out.println("ststaic");
	}

}
