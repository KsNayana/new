
public class testInheritanceDemo {

	public static void main(String[] args)
	{
		
		Employee e1=null;
		
		e1=new Employee(333,"nans",60000.0F);
		int age=90;
		
		WageEmp e2=null;
		e2=new WageEmp(555,"sam",5000,5,500);
		
		Employee e3=null;
		e3=new WageEmp(666,"Amit",5000,4,400);
		
		WageEmp we=(WageEmp)e3;
		
		Employee nayana=new Employee(111,"nayana",100.0F);
		WageEmp navya=new WageEmp(222,"navya",5000.0F,400,5);
				
		System.out.println("emp Info:" +nayana.dispEmpInfo());
		System.out.println("emp Monthly Sal:" +nayana. calcEmpBasicSal());
		System.out.println("emp Annual sal:" +nayana.calcEmpAnnualSal());
		
		System.out.println("emp Info:" +navya.dispEmpInfo());
		System.out.println("emp Monthly Sal:" +navya.calcEmpBasicSal());
		System.out.println("emp Annual sal:" +navya.calcEmpAnnualSal());
		
		System.out.println();
		WageEmp Krithika=new WageEmp(223,"Krithika",5000.0F,400,7);
		
		System.out.println("emp Info:" +Krithika.dispEmpInfo());
		System.out.println("emp Monthly Sal:" +Krithika.calcEmpBasicSal());
		System.out.println("emp Annual sal:" +Krithika.calcEmpAnnualSal());
		
		SalesManager nammu=new SalesManager(223,"nammu",5000.0F,400,5,50,3);
		
		System.out.println("emp Info:" + nammu.dispEmpInfo());
		System.out.println("emp Monthly Sal:" + nammu.calcEmpBasicSal());
		System.out.println("emp Annual sal:" + nammu.calcEmpAnnualSal());
	}

}
