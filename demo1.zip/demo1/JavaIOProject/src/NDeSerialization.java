import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class NDeSerialization 
{

	public static void main(String[] args) 
	{
		FileInputStream fis;
		ObjectInputStream oos;
		Emp ee[]=new Emp[3];
	
	try
    {	
        fis=new FileInputStream("EmpData.obj");
        oos=new ObjectInputStream(fis);
        for (int j=0;j<3;j++)
        {
        	ee[j]=(Emp)oos.readObject();
        
        System.out.println("  emp info :"+ee[j]);
        }
    }
    catch(IOException e)
    {
        e.printStackTrace();
    }
    catch(ClassNotFoundException e)
    {
        e.printStackTrace();
    }

}
}
