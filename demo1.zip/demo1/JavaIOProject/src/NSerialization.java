import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;


public class NSerialization {

	public static void main(String[] args) 
	{
		Scanner sc =new Scanner(System.in);

		Emp ee[]=new Emp[3];
		for(int i=0;i<3;i++)
		{
			System.out.println("Enter Emp Id:");
			int empId=sc.nextInt();

			System.out.println("Enter Emp Name:");
			String empName=sc.next();

			System.out.println("Enter Emp Salary:");
			Float empSal=sc.nextFloat();

			ee[i]=new Emp(empId, empName, empSal);
		}
		FileOutputStream fos;
		try
		{
			fos = new FileOutputStream("EmpData.obj");
			ObjectOutputStream oos=new ObjectOutputStream(fos);

			for(int j=0;j<3;j++)
			{
				oos.writeObject(ee[j]);
			}
			System.out.println(" Emp Object is written in a file");


		}
		catch (IOException e)
		{
			e.printStackTrace();
		}

	}

}


