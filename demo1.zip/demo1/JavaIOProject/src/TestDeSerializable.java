import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
public class TestDeSerializable {

	public static void main(String[] args) 
	{
		FileInputStream fis;
	
	try
    {
        fis=new FileInputStream("EmpData.obj");
        ObjectInputStream ois=new ObjectInputStream(fis);
        Emp e1=(Emp)ois.readObject();
        System.out.println("  emp info :"+e1);
    }
    catch(IOException e)
    {
        e.printStackTrace();
    }
    catch(ClassNotFoundException e)
    {
        e.printStackTrace();
    }

}
}
