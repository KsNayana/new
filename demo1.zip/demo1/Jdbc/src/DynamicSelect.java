import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class DynamicSelect {

	public static void main(String[] args) {

		
				Connection con = null;
				Statement st=null;
				ResultSet rs=null;
				//Scanner sc= null;
				
				try
				{
					//sc=new Scanner(System.in);
				
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
				st=con.createStatement();
				String selQry="SELECT emp_id,emp_name,emp_sal FROM emp_112001 WHERE emp_id ='5'";
				
				
				
				System.out.println("Id \t NAME \t SALARY");
				
				
				System.out.println(rs.getInt("emp_id" )+"\t"+rs.getString("emp_name")+
						"\t" +rs.getInt("emp_sal"));
				rs =st.executeQuery(selQry);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}

		}


	


