import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class TestDelete 
{

	public static void main(String[] args) 
	{
		Connection con=null;
		Statement st=null;


		try
		{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");

		String deleteQry="DELETE FROM emp_112001 WHERE emp_id ='6'";
				
		st=con.createStatement();
		int data=st.executeUpdate(deleteQry);
		System.out.println("data Deleted from table:"+data);
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
