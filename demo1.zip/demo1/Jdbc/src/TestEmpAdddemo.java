import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class TestEmpAdddemo 
{

	public static void main(String[] args)
	{
		Connection con=null;
		Statement st=null;


		try
		{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");

			String insertQry="INSERT INTO emp_112001 (emp_id,emp_name,emp_sal)"
					+ "VALUES(666,'Kavitha S',80000)";
			st=con.createStatement();
			int data=st.executeUpdate(insertQry);
			System.out.println("data inserted in table:"+data);

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
