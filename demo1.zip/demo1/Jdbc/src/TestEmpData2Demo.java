import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;
import java.sql.*;


public class TestEmpData2Demo 
{

	public static void main(String[] args)
	{
		Connection con=null;
		Scanner sc= null;
		PreparedStatement pst;

		try
		{
			sc=new Scanner(System.in);
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");

			String insertQry= "INSERT INTO emp_112001 (emp_id, emp_name, emp_sal) VALUES"
					+"(?,?,?)";

			pst=con.prepareStatement(insertQry);
			
			System.out.println("Enter no of employee");
			int count = sc.nextInt();
			for(int i=0;i<count;i++)
			{
				System.out.println("Enter Id");
				int empId=sc.nextInt();
				System.out.println("Enter Name");
				String empName=sc.next();
				System.out.println("Enter Salary");
				float empSal=sc.nextFloat();
				
				pst.setInt(1, empId);
				pst.setString(2, empName);
				pst.setFloat(3, empSal);
				int dataAdded=pst.executeUpdate();
			}
			
			System.out.println("Data is added..");
		}

		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
}
