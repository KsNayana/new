import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


public class TestResultSetMetaDemo 
{

	public static void main(String[] args) 
	{
		Connection con = null;
		Statement st=null;
		ResultSet rs=null;

	}

}
