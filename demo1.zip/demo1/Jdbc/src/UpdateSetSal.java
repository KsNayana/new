import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Scanner;


public class UpdateSetSal
{

	public static void main(String[] args) 
	{
		Connection con=null;
		Scanner sc= null;
		PreparedStatement pst;
		Statement st=null;

		try
		{

			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");

			String updaterQry="UPDATE emp_112001 SET emp_sal=emp_sal+10000 WHERE emp_sal<20000  ";

			st=con.createStatement();
			int data=st.executeUpdate(updaterQry);
			System.out.println("data inserted in table:"+data);

			

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

}
}
