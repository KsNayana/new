
public class Account
{
	private long accNum;
	private double balance;
	Person p1;
	
	public Account(long accNum, double balance, Person p1) 
	{
		
		this.accNum = accNum;
		this.balance = balance;
		this.p1=p1;
		//this.accHolder = accHolder;
	}

	public Account()
	{
		
	}

	public long getAccNum() 
	{
		return accNum;
	}

	public void setAccNum(long accNum) 
	{
		this.accNum = accNum;
	}

	public double getBalance() 
	{
		return balance;
	}

	public void setBalance(double balance)
	
	{
		this.balance = balance;
	}


	public double deposit(double bal)
	
	{
		return bal+balance;
		
	}
	public double withdraw(double moneyDrawn)
	
	{ 
		return balance-moneyDrawn;
	}


	public String dispAccount() 
	{
		return "Account [accNum=" + accNum + ", balance=" + balance + ", "
				+ p1.dispPerson() + "]";
	}
	
	
	
	
}
