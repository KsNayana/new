//import java.util.Random;
public class TestAccount {

	public static void main(String[] args) 
	{
		Person smithP=new Person("smith",34);
		Person kathyP=new Person("kathy",44);
	    double t=(double) Math.random()*10000;
	    long acc=(long)t;
	    double t2=(double) Math.random()*10000;
	    long acc2=(long)t2;
		Account smith = new Account( acc,2000,smithP);
		
		Account kathy = new Account( acc2,3000,kathyP);
		
		System.out.println("Smith Info: " +smith.dispAccount());
		System.out.println("Smith acc balance after depositing : " +smith.deposit(2000));

		System.out.println("kathy Info: " +kathy.dispAccount());
		System.out.println("kathy acc balance after withdrawing : " +kathy.withdraw(2000));


	}

}
