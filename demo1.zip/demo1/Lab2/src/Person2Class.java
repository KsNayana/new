
public class Person2Class {



	private String fName;
	private String lName;
	private char gender;
	private String phnum;
	public Person2Class()
	{
		
	}
	
	
	public String getfName()
	{
		return fName;
	}
	public String getlName()
	{
		return lName;
	}
	public char getGender()
	{
        return gender;
	}
	public String getPhoneNumber()
	{
		return phnum;
	}
	
	public void setfName(String fName)
	{
		this.fName=fName;
	}
	
	public void setlName(String lName)
	{
		this.lName=lName;
	}
	public void setgender(char gender)
	{
		this.gender=gender;
	
	}
	public void setPhoneNumber(String phnum)
	{
		this.phnum=phnum;
	
	}
	public void dispPerson2()
	{
		System.out.println("fName:  " +fName+ " \nlName:" +lName+   "\ngender:"
				+ gender+"\nPhone Number:"+phnum); 
	}

	
	
} 




