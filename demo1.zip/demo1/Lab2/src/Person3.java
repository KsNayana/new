
public class Person3 
{
	private String fName;
	private String lName;
	private Gender gender;
	private String phnum;
	public Person3()
	{
		
	}
	

	
	
	public String getfName()
	{
		return fName;
	}
	public String getlName()
	{
		return lName;
	}
	public Gender getGender()
	{
        return gender;
	}
	public String getPhoneNumber()
	{
		return phnum;
	}
	
	public void setfName(String fName)
	{
		this.fName=fName;
	}
	
	public void setlName(String lName)
	{
		this.lName=lName;
	}
	public void setgender( Gender gender )
	{
		this.gender=gender;
	
	}
	public void setPhoneNumber(String phnum)
	{
		this.phnum=phnum;
	
	}
	public void dispPerson2()
	{
		System.out.println("fName:  " +fName+ " \nlName:" +lName+   "\ngender:"
				+ gender+"\nPhone Number:"+phnum); 
	}
}
