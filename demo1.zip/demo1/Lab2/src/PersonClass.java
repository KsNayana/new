
public class PersonClass {

	private String fName;
	private String lName;
	private char gender;
	
	public PersonClass()
	{
		
	}
	
	public String getfName()
	{
		return fName;
	}
	public String getlName()
	{
		return lName;
	}
	public char getGender()
	{
        return gender;
	}
	
	public void setfName(String fName)
	{
		this.fName=fName;
	}
	
	public void setlName(String lName)
	{
		this.lName=lName;
	}
	public void setgender(char gender)
	{
		this.gender=gender;
	
	}
	
	

	
	}
 

