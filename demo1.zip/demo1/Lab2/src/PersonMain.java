public class PersonMain {

	public static void main(String[] args) {
		PersonClass p1=new PersonClass();
		p1.setfName("Nayana");
		p1.setlName("Karthik");
		p1.setgender('f');
		
		
		System.out.println("First Name:" +p1.getfName());
		System.out.println("Last Name:" +p1.getlName());
		System.out.println("Gender:" +p1.getGender());
	

	}

}
