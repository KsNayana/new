
public class PersonMain2 {

	public static void main(String[] args) {
		Person2Class p1=new Person2Class();
		p1.setfName("Nayana");
		p1.setlName("Karthik");
		p1.setgender('f');
		p1.setPhoneNumber("9906201528");
		
		p1.dispPerson2();

	}

}
