import java.util.Scanner;

public class PosOrNeg {

	public static void main(String[] args) {
		
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number to be checked");
		int number =sc.nextInt();
		
		if (number < 0)
		{
			System.out.println("number is Negagive ");
		}
		else
		{
			System.out.println("Number is Positive");
		}
	}

}
