
public class TestPerson3Main 
{
	public static void main(String[] args) 
	{
		Person3 p1=new Person3();
		p1.setfName("Nayana");
		p1.setlName("Karthik");
		p1.setgender(Gender.Female);
		p1.setPhoneNumber("9906201528");
		
		p1.dispPerson2();

	}

}
