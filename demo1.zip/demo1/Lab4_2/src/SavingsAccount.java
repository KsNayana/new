
public class SavingsAccount extends Account
{
private double minimumBalance;
private double finalMod;


public double getMinimumBalance()
{
	return minimumBalance;
}


public double getFinalMod() {
	return finalMod;
}


public void setFinalMod(double finalMod) {
	this.finalMod = finalMod;
}


public void setMinimumBalance(double minimumBalance)
{
	this.minimumBalance = minimumBalance;
}



public SavingsAccount(long accNum, double balance, Person p1) 
{
	super(accNum, balance, p1);
}


public SavingsAccount(long accNum, double balance, Person p1, double minimumBalance) {
	super(accNum, balance, p1);
	this.minimumBalance = minimumBalance;
}


@Override
public double withdraw (double moneyDrawn)

{ if(moneyDrawn<minimumBalance)
{
	System.out.println("Enter appropriate money");
}
else
	
	return super.getBalance()-moneyDrawn;

}
}
