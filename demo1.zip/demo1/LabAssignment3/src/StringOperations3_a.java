
public class StringOperations3_a 
{
	public static void main(String[] args) 
	{
		 String name ="nayana";
		 String name1 = name;
		 String catString = name + name1;
		 System.out.println(catString);
	
		 for(int i=0; i<name.length(); i++)
		 {
		    char currChar = name.charAt(i);
		    if (i%2==1)
		    {
		       name=name.replace(currChar, '#');
		     }
		     
		  }
		System.out.println(name);
		
		System.out.println(name1);
		/* for(int i=0; i<name1.length(); i++)
		 {
		    char currChar = name1.charAt(i);
		    //System.out.print(currChar);
		    
		    if (i%2==1)
		    {
		    	String tempStr=new Character(currChar).toString();
		      char  currCharU=tempStr.toUpperCase().charAt(0);
		        System.out.print(currCharU);
		     }
		    else
		    {
		    	System.out.print(currChar);
		    }
		
		 }*/
		 for(int i=0; i<name1.length(); i++)
		 {
		    char currChar = name1.charAt(i);
		   
		    if (i%2==1)
		    {
		    	 String tempStr=new Character(currChar).toString();
		       name1=name1.replace(currChar, tempStr.toUpperCase().charAt(0));
		     }
		     
		  }
		 System.out.println(name1);
	}
}

	


