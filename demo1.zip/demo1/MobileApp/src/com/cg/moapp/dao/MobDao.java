package com.cg.moapp.dao;

import java.util.ArrayList;

import com.cg.mobapp.bean.Mobiles;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobAppException;

public interface MobDao 
{
	public int addCustomer(PurchaseDetails purchaseDet)
			throws MobAppException;
	public ArrayList <Mobiles> getAllMob() 
			throws MobAppException;
	public int generatePurchaseId() 
			throws MobAppException;
	public int UpdateMob(int mobId)
			throws MobAppException;
	public int DeleteMob(int mobId)
			throws MobAppException;
	
}

