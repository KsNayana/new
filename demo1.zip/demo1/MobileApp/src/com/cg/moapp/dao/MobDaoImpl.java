package com.cg.moapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.mobapp.bean.Mobiles;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobAppException;
import com.cg.mobapp.util.DBUtil;

public class MobDaoImpl implements MobDao
{

	Connection con=null;
    Statement st=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
	@Override
	public int addCustomer(PurchaseDetails purchaseDet) throws MobAppException 
	{
		
		 String insertQry="INSERT INTO purchasedetails(purchaseid,cname,mailid,phoneno,purchasedate,mobileid)"
	                + "VALUES(?,?,?,?,sysdate,?)";
	        int dataAdded=0;
	        try
	        {
	            con=DBUtil.getCon();
	            pst=con.prepareStatement(insertQry);
	            pst.setInt (1, generatePurchaseId());
	            pst.setString(2, purchaseDet.getcName());
	            pst.setString(3,purchaseDet.getEmail());
	            pst.setString(4,purchaseDet.getPhNum());
	          
	            pst.setInt (5,purchaseDet.getMobileId());
	            
	           // pst.executeUpdate();
	            dataAdded=pst.executeUpdate();
	           
	            
	        }
	        catch (Exception e)
	        {
	        	
	            throw new MobAppException(e.getMessage());
	        }
	        finally
	        {
	            try
	            {
	            	
	                pst.close();
	                con.close();
	            }
	            catch (SQLException e)
	            {
	                throw new MobAppException(e.getMessage());
	            }
	        }
	        return dataAdded;
	    }
	
	@Override
	public ArrayList<Mobiles> getAllMob() throws MobAppException 
	{
		ArrayList<Mobiles> mobList=new ArrayList<Mobiles>();
        String selectQry="Select * from mobiles ";
        Mobiles mb=null;
        try
        {
            con=DBUtil.getCon();
            st=con.createStatement();
            rs=st.executeQuery(selectQry);
            while(rs.next())
            {
               mb=new Mobiles(rs.getInt("mobileId"),rs.getString("name"),
                        rs.getFloat("price"),rs.getInt(" quantity"));
                mobList.add(mb);
            }
        }
        catch (Exception e)
        {
            throw new MobAppException(e.getMessage());
        } 
        finally
        {
            try
            {
            	rs.close();
                st.close();
                con.close();
            }
            catch (SQLException e)
            {
                throw new MobAppException(e.getMessage());
            }
        }
        return mobList;
		
		
	}
	@Override
	public int generatePurchaseId() throws MobAppException 
	{
	
		 String qry="SELECT mob_seq.NEXTVAL FROM DUAL";
	        int generatedVal;
	        try
	        {
	            con=DBUtil.getCon();
	            st=con.createStatement();
	            rs=st.executeQuery(qry);
	            rs.next();
	            generatedVal=rs.getInt(1);
	            
	        }
	        catch (Exception e)
	        {
	            throw new MobAppException(e.getMessage());
	        }
	        finally
	        {
	            try 
	            {
	                rs.close();
	                st.close();
	                con.close();
	            } 
	            catch (SQLException e)
	            {
	                throw new MobAppException(e.getMessage());
	            }
	        }
	        return  generatedVal;
	}
	@Override
	public int UpdateMob(int mob) throws MobAppException 
	{
		
		return 0;
	}
	@Override
	public int DeleteMob(int mobId) throws MobAppException
	{
		String insertQry="Delete from mobiles where mobileid=?";
		int dataDelete;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(insertQry);
			pst.setInt(1, mobId);
			dataDelete=pst.executeUpdate();
		}
		catch(Exception e)
		{
			throw new MobAppException(e.getMessage());
		}
		finally
		{
			try{
				pst.close();
				con.close();
			}
		 
        catch (SQLException e)
        {
            throw new MobAppException(e.getMessage());
        }
    
    
}
		return dataDelete;
}    
   
}
