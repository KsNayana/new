package com.cg.mobapp.bean;

public class PurchaseDetails
{
	private int purchaseId;
	private String cName;
	private String email;
	private String phNum;
	private int mobileId;
	//	private String purchaseDate;
	public int getPurchaseId()
	{
		return purchaseId;
	}
	public void setPurchaseId(int purchaseId)
	{
		this.purchaseId = purchaseId;
	}
	public String getcName() 
	{
		return cName;
	}
	public void setcName(String cName) 
	{
		this.cName = cName;
	}
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public String getPhNum() 
	{
		return phNum;
	}
	
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public void setPhNum(String phNum)
	{
		this.phNum = phNum;
	}
	
	
	
	public PurchaseDetails(int purchaseId, String cName, String email,
			String phNum, int mobileId) {
		super();
		this.purchaseId = purchaseId;
		this.cName = cName;
		this.email = email;
		this.phNum = phNum;
		this.mobileId = mobileId;
	}
	public PurchaseDetails() 
	{
		super();
	}
	@Override
	public String toString() {
		return "PurchaseDetails [purchaseId=" + purchaseId + ", cName=" + cName
				+ ", email=" + email + ", phNum=" + phNum + ", mobileId="
				+ mobileId + "]";
	}
	
	
}
