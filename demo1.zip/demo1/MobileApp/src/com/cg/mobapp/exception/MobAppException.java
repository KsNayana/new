package com.cg.mobapp.exception;

public class MobAppException extends Exception
{
	public MobAppException(String msg)
	{
		super(msg);
	}
}
