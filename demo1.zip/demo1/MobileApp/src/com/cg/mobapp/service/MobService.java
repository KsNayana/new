package com.cg.mobapp.service;

import java.util.ArrayList;

import com.cg.mobapp.bean.Mobiles;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobAppException;

public interface MobService
{
	public int addCustomer(PurchaseDetails cust)
			throws MobAppException;
	public ArrayList <Mobiles> getAllMob() 
			throws MobAppException;
	public int generatePurchaseId() 
			throws MobAppException;
	public int UpdateMob(int mob)
			throws MobAppException;
	public int DeleteMob(int mobId)
			throws MobAppException;
	
	public boolean validateDigit(int MobileId) throws MobAppException;
	
	public boolean validateCustomerName(String cName) throws MobAppException;
	
	public boolean validateEmail(String mailId) throws MobAppException;
	
	public boolean validatephNo(String phoneNo) throws MobAppException;
	
	}
