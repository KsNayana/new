package com.cg.mobapp.service;

import java.util.ArrayList;
import java.util.regex.Pattern;
import com.cg.moapp.dao.MobDao;
import com.cg.moapp.dao.MobDaoImpl;
import com.cg.mobapp.bean.Mobiles;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobAppException;

public class MobServiceImpl implements MobService
{
	MobDao mobDao=null;
    public MobServiceImpl()
    {
        mobDao=new MobDaoImpl();
    }
	@Override
	public int addCustomer(PurchaseDetails cust) throws MobAppException
	{
		
		 return mobDao.addCustomer(cust);
	}

	@Override
	public ArrayList<Mobiles> getAllMob() throws MobAppException 
	{
		
		return mobDao.getAllMob();
	}

	@Override
	public int generatePurchaseId() throws MobAppException
	{
		
		return mobDao.generatePurchaseId();
	}

	@Override
	public int UpdateMob(int mob) throws MobAppException
	{
		
		return mobDao.UpdateMob(mob);
	}

	@Override
	public int DeleteMob(int mobId) throws MobAppException 
	{
		
		return mobDao.DeleteMob( mobId);
	}

	@Override
	public boolean validateDigit(int MobileId) throws MobAppException 
	{
		
		String numPattern="[0-9]{4}";
    	if(Pattern.matches(numPattern, new Integer(MobileId).toString()))
    			{
    				return true;
    			}
    	else
    	{
    		throw new MobAppException
    		("Only Min 4 digits allowed in empId and other exceptions");
    	}
	}

	@Override
	public boolean validateCustomerName(String cName) throws MobAppException
	{
	

    	String namePattern="[A-Z][a-z]{2,20}";
    	if(Pattern.matches(namePattern,cName))
    	{
    		return true;
    	}
    	else 
    	{
    		throw new MobAppException
    		("Only Characters are allowed and starts with Capital..eg Nayana");
    	}
	}

	@Override
	public boolean validateEmail(String mailId) throws MobAppException 
	{
		String emailPattern="[a-z]+[@][a-z]+[.][a-z]+";
		if(Pattern.matches(emailPattern,mailId))
    	{
    		return true;
    	}
    	else 
    	{
    		throw new MobAppException
    		("Enter valid Email id eg:nayanakattas@gmail.com");
    	}
		
	}

	@Override
	public boolean validatephNo(String phoneNo) throws MobAppException
	{
		
		String numPattern="[0-9]{10}";
    	if(Pattern.matches(numPattern, phoneNo))
    			{
    				return true;
    			}
    	else
    	{
    		throw new MobAppException
    		("Only Min 10 digits allowed in empId and other exceptions");
    	}
	}

}
