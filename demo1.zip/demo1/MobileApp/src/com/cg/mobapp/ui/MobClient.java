package com.cg.mobapp.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.mobapp.bean.Mobiles;
import com.cg.mobapp.bean.PurchaseDetails;
import com.cg.mobapp.exception.MobAppException;
import com.cg.mobapp.service.MobService;
import com.cg.mobapp.service.MobServiceImpl;



public class MobClient {
	static Scanner sc = null;
	static MobService mobSer=null;

	public static void main(String[] args) 
	{
		mobSer=new MobServiceImpl();
		sc=new Scanner(System.in);
		int choice = 0;
		while (true)
		{
			System.out.println("What do u want to Do?");
			System.out.println("1:Insert Customer\t" +"2:Update quantity\t"
					+"3:View Mob Details\t" +"4:search mob based o range"+ "5:exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: insertCustomer();
			break;
			case 2: UpdateQuantity();
			break;
			case 3: ViewDetails();
			break;
			case 4: delete();
			break;

			default: System.exit(0);
			}		


		}

	}
	/*************Main ends Here*******************************/
	public static void insertCustomer()
	{

		System.out.println("Enter Customer Name:");
		String cName=sc.next();

		try
		{
			if(mobSer.validateCustomerName(cName))
			{
				System.out.println("Enter email  Id: ");
				String mailId=sc.next();

				if(mobSer.validateEmail(mailId))
				{
					System.out.println("Enter phone number: ");
					String phnum=sc.next();
					if(mobSer.validatephNo(phnum))
					{
						System.out.println("Enter MobileId number: ");
						int mobId=sc.nextInt();
						if(mobSer. validateDigit(mobId))
						{
							PurchaseDetails pd=new PurchaseDetails();
							pd.setcName(cName);
							pd.setEmail(mailId);
							pd.setPhNum(phnum);
							pd.setMobileId(mobId);
							int dataAdded=mobSer.addCustomer(pd);

							if(dataAdded==1)
							{
								System.out.println("Purchase Data Added:");
							}
							else
							{
								System.out.println("May be some Exceptions occured while Addition");

							}
						}
					}


				}
			}
		}
			catch (MobAppException e)
			{

				System.out.println(e.getMessage());
			}

		}
		/*******************************************************************/
		public static void UpdateQuantity()
		{



		}
		/***********************************/
		public static void  ViewDetails()
		{

			try{
				ArrayList<Mobiles> mobList=
						mobSer.getAllMob();
				for(Mobiles mb:mobList)
				{
					System.out.println(mb);
				}
			}
			catch(MobAppException e)
			{
				System.out.println("SomeException");
			}
		}
		/****************************************************/
		public static void Search()
		{

		}

	}

