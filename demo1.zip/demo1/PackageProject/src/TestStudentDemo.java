import com.cg.bat.Batch;
import com.cg.stu.Student;

public class TestStudentDemo
{

	
	public static void main(String[] args) 
	{
		Batch javaBatch=new Batch("JEE_Propel_001","8:30 to 6.00","Anjulatha Temhare");
		
		Batch vNV=new Batch("VNV_PT_002","8:30 to 6.00","Shilpa Bhosale");

		Batch oracle=new Batch("OraApp_ABridge_003","8:30 to 6.00","Sachin naradekar");
		
		Student student1 = new Student(111,"ronak",90,javaBatch);
		Student student2 = new Student(112,"ram",92,vNV);
		Student student3 = new Student(113,"sham",94,oracle);
		System.out.println(student1.dispStuInfo());

		System.out.println(student1.dispStuInfo());
		System.out.println(student2.dispStuInfo());
		System.out.println(student3.dispStuInfo());

	}

}
