import java.util.Scanner;

public class TestDate {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		
		for(int i=0; i<3;i++)
		{
			System.out.println("Enter Name of person:");
			
			String name=sc.next();
			
			System.out.println("Enter day:");
			int dayOfDoj= sc.nextInt();
			
			System.out.println("Enter Month:");
			int monOfDoj= sc.nextInt();
			
			System.out.println("Enter Year:");
			int yearOfDoj= sc.nextInt();
			
			Date emp=new Date(dayOfDoj, monOfDoj, yearOfDoj);
			
			System.out.println("Emp DOJ:"+name+"  DOJ     "+  emp.dispDate());
		}

		
		
		
	}

}
