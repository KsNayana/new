package employee;

public class Employee {

	private String empName;
	private int empId;
	private float empSal;
	private char empGen;
	
	 public Employee(String empName,int empId, float empSal,char empGen)
	    {
		 this.empName=empName;
		 this.empId=empId;
		 this.empSal=empSal;
		 this.empGen=empGen;
		 
	    	
	    }
	    public String dispEmployee()
	    {
	    	return empName+"-"+empId+"-"+empSal+"-"+empGen;
	    }
}
