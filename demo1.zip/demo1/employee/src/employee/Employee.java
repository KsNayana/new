package employee;

public class Employee {

	private String empname;
	private int empid;
	private float empsal;
	private char empgen;
	
	 public Employee(String empname,int empid, float empsal,char empgen)
	    {
		 this.empname=empname;
		 this.empid=empid;
		 this.empsal=empsal;
		 this.empgen=empgen;
		 
	    	
	    }
	    public String dispEmployee()
	    {
	    	return empname+"-"+empid+"-"+empsal+"-"+empgen;
	    }
}
