package employee;

import java.util.Scanner;


public class Nemployee {


		
		public static void main(String[] args) {
			Scanner sc =new Scanner(System.in);
			System.out.println("Enter the number of employee");
			int count=sc.nextInt();
			Employee allemployees[] = new Employee[count];
			
			
			String empNames = null;
			int empId=0;
			float empSal=0;
			char empGen=' ';
			
			
			
			for (int i=0;i<allemployees.length;i++)
			{
	            System.out.println("Enter Name of person:");
				
				 empNames=sc.next();
				
				System.out.println("Enter Id:");
				 empId= sc.nextInt();
				
				System.out.println("Enter salary:");
				 empSal= sc.nextFloat();
				 
				
				 
				 allemployees[i] =new Employee(empNames,empId,empSal,empGen);
			}
				 
				 
			for (int j=0;j<allemployees.length;j++)
			{
				System.out.println( "Details:"  +allemployees[j].dispEmployee());
				
			}	 
				 
				

	}

}
