
public class Emp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee Emp1=new Employee("nayana", 42, 20000,'F');
		 System.out.println("emp details are:" +Emp1.dispEmpInfo());
		 
		 
		 Employee Emp2=new Employee("Ram", 43, 200,'M');
		 System.out.println("emp details are:" +Emp2.dispEmpInfo());
		 
		 Employee Emp3=new Employee();
		 System.out.println("emp details are:" +Emp3.dispEmpInfo());
	}

}
