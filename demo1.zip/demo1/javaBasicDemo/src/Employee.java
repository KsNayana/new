
public class Employee {
	private String Empname;
	private int Empid;
	private float Empsalary;	
	private char Empgender;
	
	public  Employee()
	 {
		Empname="Unknown";
		Empid=0;
		Empsalary=0.0F;
		Empgender=' ';
		
	 }
	public Employee(String Empname, int Empid, float Empsal,char Empgen)
	 {
		this.Empname=Empname;
		this.Empid=Empid;
		this.Empsalary=Empsal;
		this.Empgender=Empgen;
		 System.out.println("emp details are:");
		
	 }
	 public String dispEmpInfo()
	  {
		  return Empname+"-"+Empid+"-"+Empsalary+"-"+Empgender;
	  }

	   
	  public float calcBasicSal()
	  {
		  return Empsalary;
	  }
}
