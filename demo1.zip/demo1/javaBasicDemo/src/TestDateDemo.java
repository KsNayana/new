
public class TestDateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   Date nayanaDOJ=new Date(13, 12, 2017);
		  
		   
		   System.out.println("nayana DOJ is:" +nayanaDOJ.dispDate());
		   
		   
		   Date KrishhDOJ=new Date(03, 02, 2013);
		  
		  
		   System.out.println("Krishh DOJ is:" +KrishhDOJ.dispDate());
		   

		   Date unknownDOJ=new Date();
	
		  
		   System.out.println("unknown DOJ is:" +unknownDOJ.dispDate());
		   
		   
		   
	}

}
