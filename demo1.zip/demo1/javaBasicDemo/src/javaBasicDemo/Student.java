package javaBasicDemo;

public class Student {

	private int rollNo;
	private String stuName;
	private int marks;
	
	public Student()
	{
		
	}
	
	public int getRollNo()
	{
		return rollNo;
	}
	public String getStuName()
	{
		return stuName;
	}
	public int getMark()
	{
        return marks;
	}
	
	public void setrollNo(int rollNo)
	{
		this.rollNo=rollNo;
	}
	
	public void setStuName(String stuName)
	{
		this.stuName=stuName;
	}
	public void setMark(int mark)
	{
		this.marks=mark;
	}
}
