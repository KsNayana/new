package javaBasicDemo;

public class TestStudentBeanDemo {

	public static void main(String[] args) {
		
		Student s1=new Student();
		s1.setrollNo(111);
		s1.setStuName("Pravin");
		s1.setMark(45);
		
		
		System.out.println("Roll No:" +s1.getRollNo());
		System.out.println("Roll No:" +s1.getStuName());
		System.out.println("Roll No:" +s1.getMark());
		
		System.out.println("************************");
		
		Student s2=new Student();
		s2.setrollNo(222);
		s2.setStuName("vaishali");
		s2.setMark(67);
		
		
		
		System.out.println("Roll No:" +s2.getRollNo());
		System.out.println("Roll No:" +s2.getStuName());
		System.out.println("Roll No:" +s2.getMark());
		
	}

}
