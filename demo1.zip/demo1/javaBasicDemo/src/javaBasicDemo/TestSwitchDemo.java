package javaBasicDemo;

public class TestSwitchDemo {

	public static void main(String[] args) {
		int day= Integer.parseInt(args[0]);
		switch(day)
		{
		case 6:System.out.println("its saturday");
		break;
		case 7:System.out.println("its sunday");
		break;
		default:
			System.out.println("its week days");
		}
	}
}
